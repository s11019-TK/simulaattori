﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bphysics : MonoBehaviour {
    //f = m*(v/t) -> v = (f/m)*t
    private Rigidbody rb;
    public float force,angle;
    private float vx, vy, t, mass;
    bool f_enabled = false;
	// Use this for initialization
	void Start () {
        rb = GetComponent<Rigidbody>();
        mass = rb.mass;
        t = 0;
	}
	
	// Update is called once per frame
	void Update () {
        
        if (Input.GetMouseButtonDown(0))
        {
            
            vx = (force / mass) * 0.01f * Mathf.Cos(Mathf.Deg2Rad * angle);
            vy = (force / mass) * 0.01f * Mathf.Sin(Mathf.Deg2Rad * angle);
            Debug.Log("vx = " + vx + ", vy = " + vy);

            f_enabled = true;
        }

        if(f_enabled)
        {
            t += Time.deltaTime;
            rb.transform.Translate(new Vector3(vx * Mathf.Cos(Mathf.Deg2Rad * angle) * t, vy * Mathf.Sin(Mathf.Deg2Rad * angle) * t - 0.5f * 9.81f * Mathf.Pow(t, 2), 0)); //

            
        }

        

    }

    

    
}
