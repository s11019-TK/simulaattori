﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Aphysics : MonoBehaviour {


    private Rigidbody rb;
    public float force;
    public float angle;


	// Use this for initialization
	void Start () {
        rb = GetComponent<Rigidbody>();
	}
	
	// Update is called once per frame
	void Update () {
		if(Input.GetMouseButtonDown(0))
        {
            Vector3 dir = Quaternion.AngleAxis(angle, Vector3.forward) * Vector3.right;
            rb.AddForce(dir * force);

        }
	}
}
